const config = {
  apiUrl: 'http://localhost:4972'
};

export default config;
